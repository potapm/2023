<template>
  <div class="home-view"></div>
</template>

<script setup></script>

<style lang="scss" scoped>
.home-view__main {
  display: flex;
}
</style>
